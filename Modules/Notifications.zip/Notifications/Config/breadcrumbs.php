<?php

return [

    'notifications.index' => [
        'label' => 'notifications::page_titles.notifications.index',
        'parent' => null,
        'translate' => true,
    ],

    'notifications.create' => [
        'label' => 'notifications::page_titles.notifications.create',
        'parent' => 'notifications.index',
        'translate' => true,
    ],

    'notifications.show' => [
        'label' => 'notifications::page_titles.notifications.show',
        'parent' => 'notifications.index',
        'translate' => true,
    ],

    'notifications.settings' => [
        'label' => 'notifications::page_titles.notifications.settings',
        'parent' => 'notifications.index',
        'translate' => true,
    ],

    'notifications.test' => [
        'label' => 'notifications::page_titles.notifications.test',
        'parent' => 'notifications.index',
        'translate' => true,
    ],

];